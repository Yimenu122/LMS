-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2025 at 04:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_ms`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_details`
--

CREATE TABLE `book_details` (
  `Book_ID` int(11) NOT NULL,
  `Book_Name` varchar(100) NOT NULL,
  `Author` varchar(50) NOT NULL,
  `Quntity` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_details`
--

INSERT INTO `book_details` (`Book_ID`, `Book_Name`, `Author`, `Quntity`) VALUES
(1, 'Java', 'harvert schildit', 6),
(2, 'C++', 'sntanley b', 2),
(3, 'Algorithm', 'Bin', 4),
(4, 'CSS', 'Known', 5),
(5, 'PHP', 'abebe', 5),
(6, 'python', 'al sweigart', 2);

-- --------------------------------------------------------

--
-- Table structure for table `issue_book_details`
--

CREATE TABLE `issue_book_details` (
  `id` int(11) NOT NULL,
  `book_id` int(8) NOT NULL,
  `book_name` varchar(150) NOT NULL,
  `student_id` int(12) NOT NULL,
  `student_name` varchar(20) NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `Penality` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `issue_book_details`
--

INSERT INTO `issue_book_details` (`id`, `book_id`, `book_name`, `student_id`, `student_name`, `issue_date`, `due_date`, `status`, `Penality`) VALUES
(1, 2, 'C++', 3, 'Muluken', '2025-04-21', '2025-04-24', 'returned', 0),
(2, 3, 'PHP', 1, 'Yimenu', '2025-04-20', '2025-04-22', 'returned', 0),
(6, 4, 'CSS', 3, 'Muluken', '2025-04-22', '2025-04-25', 'returned', 0),
(9, 2, 'C++', 4, 'Sami', '2025-04-22', '2025-04-26', 'pending', 0),
(10, 2, 'C++', 6, 'Sami', '2025-04-22', '2025-04-26', 'pending', 0),
(11, 20, 'C++', 2, 'Sami', '2025-04-16', '2025-04-30', 'pending', 0),
(13, 2, 'C++', 3, 'Muluken', '2025-04-25', '2025-04-27', 'returned', 0),
(15, 5, 'PHP', 1, 'Yimenu', '2025-04-15', '2025-04-24', 'returned', 0),
(16, 5, 'PHP', 4, 'Yezina', '2025-04-17', '2025-04-23', 'returned', 0),
(17, 2, 'C++', 3, 'Muluken', '2025-04-21', '2025-04-25', 'returned', 0),
(18, 2, 'C++', 1, 'Yezina', '2025-04-17', '2025-04-22', 'pending', 0),
(19, 6, 'python', 1, 'Yimenu', '2025-04-17', '2025-04-25', 'pending', 0),
(20, 1, 'Java', 2, 'Yeabsira', '2025-04-10', '2025-04-24', 'pending', 0),
(21, 7, '', 6, 'Yohanis', '2025-04-17', '2025-04-27', 'pending', 0),
(22, 6, 'python', 7, 'Yimenu', '2023-08-22', '2024-04-17', 'pending', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_deetails`
--

CREATE TABLE `student_deetails` (
  `Student_id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `Branch` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_deetails`
--

INSERT INTO `student_deetails` (`Student_id`, `Name`, `Course`, `Branch`) VALUES
(1, 'Yimenu', 'OOp', 'IS'),
(2, 'Yeabsira', 'OS', 'CS'),
(3, 'Muluken', 'Algorithm', 'CS'),
(4, 'Yezina', 'Datbase', 'IS'),
(5, 'Yared', 'Datbase', 'IS'),
(6, 'Yohanis', 'OOp', 'IS'),
(7, 'Tadese', 'OS', 'IS');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `UserName` varchar(20) NOT NULL,
  `Password` varchar(8) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `UserName`, `Password`, `Email`, `Phone`) VALUES
(1, 'Yimenu', '1234', 'yime@.com', '942114205'),
(3, 'Able', '1234', 'able@.com', '946158515'),
(5, 'Jo', '1234', 'jo@gmail.com', '932248849'),
(6, 'Yeabsira', '1234', 'yeab@gmail.com', '947132184'),
(8, 'Yared', '1234', 'yared@gmail.com', '934567824'),
(9, 'Dane', '1234', 'dane@gmail.com', '94634723'),
(11, 'Abebe', '1234', 'abebe@gmail.com', '9765887'),
(12, 'Sime', '1234', 'sime@gmail.com', '9567824'),
(15, 'Tadesse', '1234', 'tade@gmail.com', '+251996037579'),
(16, 'Yezina', '1234', 'yezi@gmail.com', '+251930302964'),
(17, 'Yitayal', '1234', 'yitu@gmail.com', '+2515678908'),
(18, 'Muluken', '1234', 'muli@gmail.com', '98765423'),
(19, 'yohanis', '1234', 'yohanis@gmail.com', '251234567'),
(20, 'Tigst', '1234', 'tig@gmail.com', '93456'),
(21, 'Minale', '1234', 'minale.@gmail.com', '095463987'),
(22, 'yitbarek', '8888', 'ytred', '0987654321'),
(23, 'aman', '1234', 'aman@gmail.com', '231456345'),
(24, 'Selam', '1234', 'selam@gmail.com', '9876452678');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_details`
--
ALTER TABLE `book_details`
  ADD PRIMARY KEY (`Book_ID`);

--
-- Indexes for table `issue_book_details`
--
ALTER TABLE `issue_book_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_deetails`
--
ALTER TABLE `student_deetails`
  ADD PRIMARY KEY (`Student_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_details`
--
ALTER TABLE `book_details`
  MODIFY `Book_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `issue_book_details`
--
ALTER TABLE `issue_book_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `student_deetails`
--
ALTER TABLE `student_deetails`
  MODIFY `Student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
